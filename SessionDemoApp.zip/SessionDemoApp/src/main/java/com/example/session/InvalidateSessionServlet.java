package com.example.session;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/InvalidateSession")
public class InvalidateSessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
                         throws ServletException, IOException {
        HttpSession session = request.getSession(false); // don’t create if none
        if (session != null) {
            session.invalidate();
        }

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Session Invalidated</title></head><body>");
        out.println("<h2>Your session has been invalidated.</h2>");
        out.println("<p><a href=\"SessionDemo\">Start a new session</a></p>");
        out.println("</body></html>");
        out.close();
    }
}
