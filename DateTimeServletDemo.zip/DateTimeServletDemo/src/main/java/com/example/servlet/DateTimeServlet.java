package com.example.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/datetime")
public class DateTimeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handles HTTP GET requests
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Set content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get current date and time
        Date now = new Date();

        // Output HTML response
        out.println("<html><body>");
        out.println("<h2>Current Date and Time</h2>");
        out.println("<p>" + now.toString() + "</p>");
        out.println("</body></html>");
    }
}
