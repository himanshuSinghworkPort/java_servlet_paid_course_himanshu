package com.example.session;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionDemo")
public class SessionDemoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
                         throws ServletException, IOException {
        // 1. Get (or create) the user’s session
        HttpSession session = request.getSession(true); // true → create if doesn’t exist

        // 2. Retrieve the “visitCount” attribute
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 1;
        } else {
            visitCount++;
        }

        // 3. Store the updated count back in session
        session.setAttribute("visitCount", visitCount);

        // 4. Set response type and get writer
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // 5. Generate HTML response
        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Session Demo</title></head><body>");
        out.println("<h2>Session Tracking Demo</h2>");
        out.println("<p>Your session ID: <b>" + session.getId() + "</b></p>");
        out.println("<p>Number of times you’ve accessed this page in this session: "
                    + visitCount + "</p>");

        // 6. Add a link to invalidate session
        out.println("<p><a href=\"InvalidateSession\">Invalidate Session</a></p>");

        out.println("</body></html>");
        out.close();
    }
}
