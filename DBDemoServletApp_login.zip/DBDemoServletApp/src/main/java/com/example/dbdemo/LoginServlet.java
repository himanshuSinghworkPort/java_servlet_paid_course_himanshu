package com.example.dbdemo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public LoginServlet() {
        super();
       
    }

	   String URL      ="jdbc:mysql://localhost:3306/testdbservlet?useSSL=false&serverTimezone=UTC";
	   String USER     = "root";
	   String PASSWORD = "";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 

	}
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8");
		  PrintWriter out = response.getWriter();
		  try {
		   Class.forName("com.mysql.cj.jdbc.Driver");
		   Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
		   //Statement stmt = conn.createStatement();
		  // ResultSet rs = stmt.executeQuery("SELECT id, name, email FROM users");

		   String user = request.getParameter("username");
	        String pass = request.getParameter("password");
		  
		  
	        if (user == null || pass == null || user.isEmpty() || pass.isEmpty()) {
	            request.setAttribute("error", "Both fields are required.");
	            request.getRequestDispatcher("index.html")
	                   .forward(request, response);
	            return;
	        }
		  
	        String sql = "SELECT username FROM userslogin WHERE username=? AND password=?";
	        PreparedStatement ps = conn.prepareStatement(sql);
	        
	        ps.setString(1, user);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                // login success: create session and forward
                HttpSession session = request.getSession();
                session.setAttribute("username", user);
                request.getRequestDispatcher("welcome.html")
                       .forward(request, response);
            } else {
                // failure: back to login with error
                request.setAttribute("error", "Invalid username or password.");
                request.getRequestDispatcher("index.html")
                       .forward(request, response);
            }  
		  
		  } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  catch (ClassNotFoundException cnfe) {
	            throw new ServletException("JDBC Driver not found", cnfe);
	        } 
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
